﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //clearing listbox
            lb_games.Items.Clear();
            string searchtext = txt_search.Text.Trim();
        }

        private void ReadIntoArray()
        {
            string gamename;
            StreamReader games = File.OpenText("GamesSales.txt");
            char[] delim = { '@', '=' };
            while (!games.EndOfStream)
            {
                gamename = games.ReadLine().Trim();
                
            }

        }

        private void SelectionSortByName()
        { 
            
        }

        private void SelectionSortBySales()
        {

        }

        private void BinSrch()
        {

        }

        private void DisplaySales()
        {

        }

        private void btn_name_Click(object sender, EventArgs e)
        {

        }

        private void btn_sales_Click(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {

        }

        private void rb_name_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rb_sales_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
