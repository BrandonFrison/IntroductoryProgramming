public class LinkedPriorityQueue<T> implements PriorityQueueInterface<Entry<String, Integer>> {

	private Node firstNode;
	private Node lastNode;
	
	
	public LinkedPriorityQueue()
	{
		firstNode = null;
		lastNode = null;
	}
	
	@Override
	public void add(Entry<String, Integer> newEntry) {
		// TODO Auto-generated method stub
		Node newNode = new Node((T) newEntry);
		
		if(isEmpty()){
			firstNode = newNode;
		}
		else
		{
			lastNode.setNextNode(newNode);
		}
		lastNode = newNode;
	}

	@Override
	public Entry<String, Integer> remove() {
		return null;
		// TODO Auto-generated method stub

	}

	@Override
	public Entry<String, Integer> peek() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (lastNode == null) && (firstNode == null);
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}
	public T getHeadNode()
	{
		if (isEmpty())
			return null;
		else
         return firstNode.getData();
	}
	
	public T dequeue()
	{
	  T front = getHeadNode(); 
	  assert !isEmpty();
	  
     firstNode.setData(null);
     firstNode = firstNode.getNextNode();
	  
	  return front;
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		while (!isEmpty())
		    dequeue();
	}
	
	private class Node
	{
		private T    data;  
		private Node next;  

		private Node(T dataPortion){
			data = dataPortion;
			next = null;	
		} 
		
		private Node(T dataPortion, Node nodeLink){
			data = dataPortion;
			next = nodeLink;	
		} 
		private T getData(){
			return data;
		} 

		private void setData(T newData){
			data = newData;
		} 

		private Node getNextNode(){
			return next;
		} 
		
		private void setNextNode(Node nextNode){
			next = nextNode;
		} 
	} 

}
